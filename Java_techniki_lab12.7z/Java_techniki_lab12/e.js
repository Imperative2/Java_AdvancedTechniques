var Foo = Java.type("main.Main");

print("hello");
Foo.i();